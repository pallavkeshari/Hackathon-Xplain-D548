import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
export default class NtnxPostSalesQuery extends NavigationMixin(LightningElement) {
    navigateToFreshDesk() {
        // Navigate to a URL
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: 'https://nutanixfasttrack.freshdesk.com/support/tickets/new'
            }
        },
        true // Replaces the current page in your browser history with the URL
      );
    }
    navigateToSlackChannel() {
        // Navigate to a URL
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: 'https://app.slack.com/client/T0252CLM8/C1S5MC5N0'
            }
        },
        true // Replaces the current page in your browser history with the URL
      );
    }
}